
module.exports = require('./Slider');
