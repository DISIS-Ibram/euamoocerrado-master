//wrap around components
function(Crafty, window, document) {
